#!/bin/bash

mkdir -p -p /data/vaaa
 
	 
     echo "ok"
	 
 
exit 1
 