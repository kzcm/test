 
CREATE TABLE `test` (
  `id` bigint(20) unsigned NOT NULL,
  `arg1` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '1',
  `arg2` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT 'fhfg',
  `time` datetime DEFAULT NULL COMMENT 'shijia时间',
  PRIMARY KEY (`id`)
)
;


 

ALTER TABLE `nginx_list`
ADD COLUMN `test`  varchar(12) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT 'asdsa' 
;


