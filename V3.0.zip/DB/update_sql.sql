INSERT INTO test_version (id,NAME,t_value,remark) VALUES ('49a30f16-fb80-11e9-b7e0-00e04c680046','test','kkk','备注kkk');
INSERT INTO test_version(id,NAME,t_value,remark) VALUES('111222','zzz123','zzz','备注zzz');
UPDATE test_version SET NAME='张三' WHERE id='49a4f285-fb80-11e9-b7e0-00e04c680046';