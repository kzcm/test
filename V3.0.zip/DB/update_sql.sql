------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------     2019.8.23   -----------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------

-- 节站点表中新增缓存开启策略 0关闭 1开启  2019.8.23   leibo
alter table nginx_list add cache int(2) ;

-- 站点表中新增缓存资源格式 (共9种格式存储时通过逗号隔开)   2019.8.23   leibo
alter table nginx_list add cache_types varchar (200);
------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------     2019.8.26  -----------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------

-- 站点表中新增limits访问限制开启策略 0关闭 1开启    2019.8.26   leibo
alter table nginx_list add limits int(2);

-- 站点表中新增单个ip最大连接数                        2019.8.26   leibo
alter table nginx_list add ip_num int(20);

-- 站点表中新增单个网站最大连接数           2019.8.26   leibo
alter table nginx_list add server_num int(20);

-- 站点表中新增下载速率限制               2019.8.26    leibo
alter table nginx_list add download_rate int(20);

------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------     2019.8.27   -----------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------

-- 新增正常节点与备用节点之间的关联表        2019.8.27     leibo
create table link_normal_spare_node (
  link_id int(11) NOT NULL AUTO_INCREMENT COMMENT '正常节点与备用节点之间的关联主键',
  normal_node_id varchar(50) NOT NULL COMMENT '正常节点id',
  spare_node_id varchar(50) NOT NULL COMMENT '备用节点id',
  PRIMARY KEY (`link_id`) USING BTREE
) ENGINE=InnoDB  DEFAULT CHARSET=utf8;

------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------     2019.8.28   -----------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------

-- 站点表中使用哪个节点host生成的申请的证书              2019.8.28    zhangzhe
ALTER TABLE `certificate_info`
ADD COLUMN `host`  varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '生成的证书的节点服务器host' AFTER `end_date`;
-- 站点表中申请的证书 类型             2019.8.28    zhangzhe
ALTER TABLE `nginx_list`
ADD COLUMN `pem_type`  char(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '证书类型(0为申请，1为自己输入)' AFTER `cache_types`;


-- 站点表中申请的证书  使用的第一个域名            2019.8.28    zhangzhe
ALTER TABLE `nginx_list`
ADD COLUMN `apply_name`  varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '申请证书使用的name';
-- 站点表中使用哪个节点host生成的申请的证书              2019.8.28    zhangzhe
ALTER TABLE `nginx_list`
ADD COLUMN `apply_host`  varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '用来申请证书的节点host' ;

------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------     2019.8.29   -----------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------

-- 修改域名输入的长度限制            2019.8.29    zhangzhe
ALTER TABLE `nginx_list`
MODIFY COLUMN `realm_name`  text CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '域名' ,
DROP INDEX `realm_name_index`;
-- 新增cc防御类型        2019.8.29     syy
alter table nginx_list add cc_type int(2) default 1 null comment '1 等待进入 2 验证码';
alter table nginx_list add cc_switch int(2) default 0 null comment '0 关 1 开';


-- 新增code_html文件
INSERT INTO `baixun_cdn_test`.`sys_config` (`c_key`, `c_value`, `remark`) VALUES ('code_html', '<!doctype html>
     <html>
     <head>
     <meta charset="utf-8">
     <title>验证码</title>
     <style>
         .code
         {
              font-family:Arial;
              font-style:italic;
              color:blue;
              font-size:30px;
              border:0;
              padding:2px 3px;
              letter-spacing:3px;
              font-weight:bolder;
              float:left;
              cursor:pointer;
              width:150px;
              height:50px;
              line-height:60px;
              text-align:center;
              vertical-align:middle;
              background-color:#D8B7E3;
          }
          span {
             text-decoration:none;
             font-size:12px;
             color:#288bc4;
             padding-left:10px;
         }

         span:hover {
             text-decoration:underline;
             cursor:pointer;
         }

         .bg{
         position: absolute;
         background-color: rgba(0,0,0,0.5);
         z-index: 100;
         width: 100%;
         height: 100%;
         left: 0;
         top: 0;
         display: none;
             text-align:center;
         }

         #facebook{
             margin-top:15%;
             margin-left: 40%;
         }
         .facebook_block{
             background-color:#9FC0FF;
             border:2px solid #3B5998;
             float:left;
             height:30px;
             margin-left:5px;
             width:8px;
             opacity:0.1;
             -webkit-transform:scale(0.7);
             -webkit-animation-name: facebook;
             -webkit-animation-duration: 1s;
             -webkit-animation-iteration-count: infinite;
         }
         #block_1{
             -webkit-animation-delay: .3s;
         }
         #block_2{
             -webkit-animation-delay: .4s;
         }
         #block_3{
             -webkit-animation-delay: .5s;
         }
         @-webkit-keyframes facebook{
             0%{-webkit-transform: scale(1.2);opacity:1;}
             100%{-webkit-transform: scale(0.7);opacity:0.1;}
         }

     </style>
         　　<script src="http://libs.baidu.com/jquery/2.1.4/jquery.min.js"></script>
         　　<script src="https://libs.baidu.com/jquery/2.1.4/jquery.min.js"></script>

     </head>
     <script>
         //页面加载时，生成随机验证码
         window.onload=function(){
             $("#facebook").hide();
             createCode(4);
         }

         //生成验证码的方法
         function createCode(length) {
             var code = "";
             var codeLength = parseInt(length); //验证码的长度
             var checkCode = document.getElementById("checkCode");
             ////所有候选组成验证码的字符，当然也可以用中文的
             var codeChars = new Array(0, 1, 2, 3, 4, 5, 6, 7, 8, 9,
             ''a'',''b'',''c'',''d'',''e'',''f'',''g'',''h'',''i'',''j'',''k'',''l'',''m'',''n'',''o'',''p'',''q'',''r'',''s'',''t'',''u'',''v'',''w'',''x'',''y'',''z'',
             ''A'', ''B'', ''C'', ''D'', ''E'', ''F'', ''G'', ''H'', ''I'', ''J'', ''K'', ''L'', ''M'', ''N'', ''O'', ''P'', ''Q'', ''R'', ''S'', ''T'', ''U'', ''V'', ''W'', ''X'', ''Y'', ''Z'');
             //循环组成验证码的字符串
             for (var i = 0; i < codeLength; i++)
             {
                 //获取随机验证码下标
                 var charNum = Math.floor(Math.random() * 62);
                 //组合成指定字符验证码
                 code += codeChars[charNum];
             }
             if (checkCode)
             {
                 //为验证码区域添加样式名
                 checkCode.className = "code";
                 //将生成验证码赋值到显示区
                 checkCode.innerHTML = code;
             }
         }

         //检查验证码是否正确
         function validateCode()
         {
             //获取显示区生成的验证码
             var checkCode = document.getElementById("checkCode").innerHTML;
             //获取输入的验证码
             var inputCode = document.getElementById("inputCode").value;
             var Bg = document.getElementById("bg");
             console.log(checkCode);
             console.log(inputCode);
             if (inputCode.length <= 0)
             {
                 alert("请输入验证码！");
             }
             else if (inputCode.toUpperCase() != checkCode.toUpperCase())
             {
                 alert("验证码输入有误！");
                 createCode(4);
             }
             else
             {
                 $("#code").hide();
                 $("#facebook").show();
                 $.ajax({
                     type: "GET",
                     url: “#manageUrl/server/setIpCheck",
                     success: function (data) {
                         console.log(data)
                     },
                     error: function (data) {
                         layer.msg("操作失败，请重试")
                     }
                 });

                 setTimeout(function () {
      window.location.href=window.location.href.replace("/code.html","")+"?t="+(new Date()).getTime();
                             },5000);
             }
         }
     </script>
     <body>


         <div id = "code">
             <table border="0" cellspacing="5" cellpadding="5" >
                 <tr>
                     <td> <div id="checkCode" class="code"  onclick="createCode(4)" ></div></td>
                     <td> <span onclick="createCode(4)">看不清换一张</span></td>
                     <td>验证码：</td>
                     <td><input type="text" id="inputCode"  style="float:left;" /></td>
                     <td></td>
                     <td><input type="button" onclick="validateCode()"  value="确定" /></td>
                 </tr>
             </table>
         </div>


         <div id="facebook">
             <div id=''block_1'' class=''facebook_block''></div>
             <div id=''block_2'' class=''facebook_block''></div>
             <div id=''block_3'' class=''facebook_block''></div>
         </div>


     </body>
     </html>', DEFAULT);

-- 新增wait_html文件
INSERT INTO `baixun_cdn_test`.`sys_config` (`c_key`, `c_value`, `remark`) VALUES ('wait_html', '
     <!DOCTYPE html>
     <html>
     <head>
     <meta charset="utf-8">
     <script src="http://libs.baidu.com/jquery/2.1.4/jquery.min.js"></script>
      <script src="https://libs.baidu.com/jquery/2.1.4/jquery.min.js"></script>
     <script>
            $.ajax({
                     type: "GET",
                     url: “#manageUrl/server/setIpCheck",
                     success: function (data) {
                         console.log(data)
                     },
                     error: function (data) {
                         layer.msg("操作失败，请重试")
                     }
                 });
          setTimeout(function () {
                         window.location.href=window.location.href.replace("/wait.html","")+"?t="+(new Date()).getTime();
                     },5000);
     </script>
     <style type="text/css">
     .sk-three-bounce {
             position: absolute;
             top: 50%;
             left: 50%;

             margin: 40px auto;
             width: 80px;
             text-align: center;
             positon:absolute;top:60%;left:50%;margin-top:-100px;margin-left:-150px;width:300px;height:200px;
     }
     .sk-three-bounce .sk-child {
             width: 20px;
             height: 20px;
             background-color: #333;
             border-radius: 100%;
             display: inline-block;
             -webkit-animation: sk-three-bounce 1.4s ease-in-out 0s infinite both;
             animation: sk-three-bounce 1.4s ease-in-out 0s infinite both;
     }
     .sk-three-bounce .sk-bounce1 {
             -webkit-animation-delay: -0.32s;
             animation-delay: -0.32s;
     }
     .sk-three-bounce .sk-bounce2 {
             -webkit-animation-delay: -0.16s;
             animation-delay: -0.16s;
     }
      @-webkit-keyframes sk-three-bounce {
      0%, 80%, 100% {
      -webkit-transform: scale(0);
      transform: scale(0);
     }
      40% {
      -webkit-transform: scale(1);
      transform: scale(1);
     }
     }
      @keyframes sk-three-bounce {
      0%, 80%, 100% {
      -webkit-transform: scale(0);
      transform: scale(0);
     }
      40% {
      -webkit-transform: scale(1);
      transform: scale(1);
     }
     }

     </style>
     </head>
     <body>
     <div class="sk-three-bounce">
       <div class="sk-child sk-bounce1"></div>
       <div class="sk-child sk-bounce2"></div>
       <div class="sk-child sk-bounce3"></div>
       <p><h3>进入网站中</h3></p>
     </div>
     </body>
     </html>', DEFAULT);



-- 新增DNS域名表        2019.8.29    leibo
CREATE TABLE `domin_list` (
  `domin_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'dns域名主键',
  `domin` varchar(255) DEFAULT NULL COMMENT 'dns域名',
  `account` varchar(255) DEFAULT NULL COMMENT '登录账号',
  `api_token` varchar(255) DEFAULT NULL COMMENT 'dns对应的apiToken',
  `remark` text COMMENT '备注',
  `insert_time` datetime DEFAULT NULL COMMENT '插入时间',
  PRIMARY KEY (`domin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;
   -- 用户输入的证书 私钥文本域  2019.09.02 zhangzhe
ALTER TABLE `nginx_list`
ADD COLUMN `privkey`  text CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '私钥文本域' ;
-- 用户输入的证书 证书文本域  2019.09.02 zhangzhe
ALTER TABLE `nginx_list`
ADD COLUMN `fullchain`  text CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '证书文本域' ;
  -- 证书申请的时候默认使用第一个域名 用来作为续期证书的证书名称  2019.09.02 zhangzhe
ALTER TABLE `certificate_info`
ADD COLUMN `domin_name`  varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '申请证书使用的domain证书名称(即默认输入域名第一个)';

--新增部署状态和部署失败原因字段    2019.09.03 leibo
alter table nginx_list add deploy_status  int(2) unsigned zerofill DEFAULT '00' COMMENT '部署状态 0.未部署 1.部署中 2.部署成功 3.部署失败';
alter table nginx_list add deploy_error_msg  text COMMENT '部署失败原因';

--新增DNS解析id    2019.09.04 leibo
alter table product add dns_id  int(11)  COMMENT 'dns域名主键';
--新增DNS状态       2019.09.04 leibo
alter table domin_list add status  int(2) unsigned zerofill DEFAULT '00' COMMENT 'DNS状态 0.普通 1.默认';
-- 用户选择https协议的时候  源私钥文本域  2019.09.04 zhangzhe
ALTER TABLE `nginx_list`
ADD COLUMN `origin_privkey`  text CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '选择https协议源私钥文本域' ;
-- 用户选择https协议的时候  源证书文本域  2019.09.04 zhangzhe
ALTER TABLE `nginx_list`
ADD COLUMN `origin_fullchain`  text CHARACTER SET utf8 COLLATE utf8_general_ci NULL COMMENT '选择https协议源证书文本域';

------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------     2019.09.05   -----------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------

-- 是否取消https访问(0为否 1为是)    2019.09.05 zhangzhe
ALTER TABLE `nginx_list`
ADD COLUMN `cancle_https`  int NULL COMMENT '是否取消https访问(0为否 1为是)' ;

--nginx_node新增系统用户id,分配的系统用户id   2019.09.05 leibo
alter table nginx_node add user_id  int(10)  COMMENT '系统用户id';
alter table nginx_node add  distribution_user_id varchar (200) COMMENT '分配的系统用户id';
--product新增系统用户id,分配的系统用户id   2019.09.05 leibo
alter table product add user_id  int(10)  COMMENT '系统用户id';
alter table product add  distribution_user_id varchar (200) COMMENT '分配的系统用户id';
--nginx_list新增系统用户id,分配的系统用户id   2019.09.05 leibo
alter table nginx_list add user_id  int(10)  COMMENT '系统用户id';
alter table nginx_list add  distribution_user_id varchar (200) COMMENT '分配的系统用户id';
--domin_list新增系统用户id,分配的系统用户id   2019.09.05 leibo
alter table domin_list add user_id  int(10)  COMMENT '系统用户id';
alter table domin_list add  distribution_user_id varchar (200) COMMENT '分配的系统用户id';
--white_group新增系统用户id,分配的系统用户id   2019.09.05 leibo
alter table white_group add user_id  int(10)  COMMENT '系统用户id';
alter table white_group add  distribution_user_id varchar (200) COMMENT '分配的系统用户id';
--black_group新增系统用户id分配的系统用户id   2019.09.05 leibo
alter table black_group add user_id  int(10)  COMMENT '系统用户id';
alter table black_group add  distribution_user_id varchar (200) COMMENT '分配的系统用户id';
--country_group新增系统用户id分配的系统用户id   2019.09.05 leibo
alter table country_group add user_id  int(10)  COMMENT '系统用户id';
alter table country_group add  distribution_user_id varchar (200) COMMENT '分配的系统用户id';

------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------     2019.09.06   -----------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------

--role  新增查看权限的主键id   2019.09.07 leibo
alter table role add  view_permission_id int (5) COMMENT '查看权限主键id';

--新增表view_permission 2019.09.07 leibo
CREATE TABLE `view_permission` (
  `id` int(5) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT NULL COMMENT '查看权限名称',
  `view_code` varchar(50) DEFAULT NULL COMMENT '唯一标识',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- 申请证书后使用的缓存证书的id    2019.09.07 zhangzhe
ALTER TABLE `nginx_list`
ADD COLUMN `certificate_id`  bigint UNSIGNED NULL DEFAULT NULL COMMENT '申请证书后使用的缓存证书的id'  ;

--role  新增path路径   2019.09.09 leibo
alter table role add  `path` varchar(255) DEFAULT NULL;

--link_user_domin 新增表(默认的DNS解析跟人有关)  2019.09.11 leibo
CREATE TABLE `link_user_domin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(20) DEFAULT NULL COMMENT '系统用户id',
  `domin_id` int(20) DEFAULT NULL COMMENT '默认DNSId',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


--表view_permission中起始默认值  2019.09.17 leibo
INSERT INTO `view_permission` VALUES (1, '全部', 'viewAll');
INSERT INTO `view_permission` VALUES (2, '部分', 'viewSection');
INSERT INTO `view_permission` VALUES (3, '唯一', 'viewUnique');

--表role中新增字段,原有数据新增默认值 2019.09.17 leibo
--超管
UPDATE role SET view_permission_id = 1,path = 1 WHERE id = 1;
--系统管理员
UPDATE role SET view_permission_id = 2,path = 2 WHERE id = 2;
--普管
UPDATE role SET view_permission_id = 2,path = 1/1 WHERE id = 3;

--表nginx_list中新增字段    2019.09.20  leibo
alter table nginx_list add `transfer_dns_id` varchar(200)  DEFAULT NULL COMMENT '转移的DNS记录id';

--新增表 transfer_node_list (节点转移记录表)   2019.09.21  leibo
CREATE TABLE `transfer_node_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `node_id` varchar(50) DEFAULT NULL COMMENT '被转移节点id',
  `transfer_node_id` varchar(50) DEFAULT NULL COMMENT '转移节点id',
  `insert_time` datetime DEFAULT NULL COMMENT '插入时间',
  `res` int(2) unsigned zerofill DEFAULT '00' COMMENT '转移结果 0.开始转移 1.成功 2.失败',
  `error_msg` varchar(255) DEFAULT NULL COMMENT '转移失败原因',
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;


------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------     2019.09.24   -----------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------------------
-- 新增操作日志表记录
CREATE TABLE `operate_log` (
  `id` varchar(50) NOT NULL,
  `userid` int(10) not null ,
  `username` varchar(50)   COMMENT '用户名',
  `operate_name` varchar(50)   COMMENT '操作名称',
   `url` varchar(2000)   COMMENT '访问路径',
  `method` varchar(50)   COMMENT '访问类型',
  `params` text   COMMENT '访问参数',
  `status_code` int(5)   COMMENT '访问code',
  `operate_ip`varchar(50)   COMMENT '操作ip',
  `operate_time` timestamp COMMENT '操作时间',
  PRIMARY KEY (`id`) USING BTREE,
  KEY `operate_log_operate_time_index` (`operate_time`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='操作日志';


--新增缓存时间字段 leibo  2019.9.27
alter table nginx_list add cache_time  varchar(10)  COMMENT '缓存时间';

--新增代理ip表 leibo 2019.9.27
CREATE TABLE `proxy_ip` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '代理ip主键id',
  `ip` varchar(255) DEFAULT NULL COMMENT 'ip地址',
  `ip_address` varchar(255) DEFAULT NULL COMMENT 'ip所在地理位置',
  `port` int(5) DEFAULT NULL COMMENT 'ip对应端口号',
  `user_name` varchar(255) DEFAULT NULL COMMENT '代理ip用户名',
  `pass_word` varchar(255) DEFAULT NULL COMMENT '代理ip密码',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 更新错误信息 zhangzhe 2019.9.29
INSERT INTO `sys_config` VALUES ('update_msg', '', '');
-- 更新状态 0为为更新 1为更新中 2更新成功 3更新失败 zhangzhe 2019.9.29
INSERT INTO `sys_config` VALUES ('update_statue', '0', '');
-- 读取版本号以及 下载jar文件路径的接口 zhangzhe 2019.9.29
INSERT INTO `sys_config` VALUES ('url', 'http://manage.sheyy.co/version/getNewVersion', '');
--读取当前版本号 zhangzhe 2019.9.29
INSERT INTO `sys_config` VALUES ('version_num', 'V1.0', '');


--新增失败次数字段 leibo  2019.9.29
alter table proxy_ip add error_num  int(10)  COMMENT '失败次数';



--新增节点转移名称冗余字段  leibo  2019.10.8
alter table transfer_node_list add node_name  VARCHAR(50)  COMMENT '被转移节点名称';
alter table transfer_node_list add transfer_node_name  VARCHAR(50)  COMMENT '转移节点名称';

-- 读取版本号以及 下载jar文件路径的接口 zhangzhe 2019.9.29
update sys_config set  c_value ='https://manage.sheyy.co/version/getNewVersionFile' where c_key='url'

-- 增加路径ip zhangzhe  2019.10.09
CREATE TABLE `local_name` (
  `l_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `insert_time` datetime DEFAULT NULL COMMENT '创建时间',
  `local_name` varchar(500) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT 'local的名称',
  `l_ips` text CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '对应的ips',
  `nginx_id` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '' COMMENT 'nginx_list的id',
  PRIMARY KEY (`l_id`)
)

-- 主服务需要添加的表  zhangzhe  2019.10.11
CREATE TABLE `version_info` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `insert_time` datetime NOT NULL,
  `version_num` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '版本号信息',
  `file_url` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '下载zip路径',
  PRIMARY KEY (`id`)
)


--新增被墙域名表  leibo  2019.10.12
CREATE TABLE `wall_domin` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `wall_domin` text COMMENT '被墙域名',
  `related_nginx` varchar(50) DEFAULT NULL COMMENT '相关站点主键',
  `status` int(2) DEFAULT NULL COMMENT '处理状态 0：未处理 1：已处理 2：处理失败',
  `insert_time` datetime DEFAULT NULL COMMENT '生成时间',
  `last_update_time` datetime DEFAULT NULL COMMENT '最后一次处理时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


--nginx_node新增节点状态并兼容原数据为数据设置默认值正常   2019.10.16 leibo
alter table nginx_node add current_state  int(2)  COMMENT '节点状态 0：异常 1：正常';
update  nginx_node set  current_state = 1;

--nginx_node_log 新增站点访问统计日志   2019.10.16 zengwenchao
CREATE TABLE `nginx_node_log`  (
  `id` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `domain` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT '' COMMENT '节点ip',
  `visit_map` varchar(2000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '访问热力图',
  `visit_url` varchar(2000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '访问url分布',
  `visit_count` varchar(2000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '访问次数',
  `response_time` varchar(2000) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL COMMENT '平均响应时间',
  `lastInit_time` varchar(50) CHARACTER SET utf8 COLLATE utf8_croatian_ci NULL DEFAULT NULL COMMENT '日期',
  `node_id` varchar(50) CHARACTER SET utf8 COLLATE utf8_croatian_ci NULL DEFAULT NULL COMMENT '节点id',
  `http_code` varchar(2000) CHARACTER SET utf8 COLLATE utf8_croatian_ci NULL DEFAULT NULL COMMENT '访问code',
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `node_log_time_index`(`lastInit_time`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_croatian_ci COMMENT = '节点日志' ROW_FORMAT = Compact;

SET FOREIGN_KEY_CHECKS = 1;


--nginx_node 新增日志黑名单    2019.10.17  leibo
alter table nginx_list add log_black_lists text CHARACTER SET utf8 COLLATE utf8_general_ci COMMENT '日志黑名单ip地址  逗号（,）隔开';
--新增日志封禁表   2019.10.17 leibo
CREATE TABLE `log_ban` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `nginx_id` varchar(50) DEFAULT NULL COMMENT '站点id',
  `nginx_name` text COMMENT '站点名称',
  `node_ip` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL COMMENT '节点ip',
  `ban_ip` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL COMMENT '封禁ip',
  `ban_type` int(2) DEFAULT NULL COMMENT '封禁类型 0：限时 1：永久',
  `ban_status` int(2) DEFAULT NULL COMMENT '封禁状态 0：封禁中 1：已解封',
  `ban_time` datetime DEFAULT NULL COMMENT '封禁时间',
  `unblock_time` datetime DEFAULT NULL COMMENT '解封时间',
  `insert_time` datetime DEFAULT NULL COMMENT '插入时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--在系统用户权限树新增日志封禁记录   2019.10.17 leibo
INSERT INTO `permission`(`name`, `pid`, `zindex`, `istype`, `descpt`, `code`, `icon`, `page`, `insert_time`, `update_time`) VALUES ('日志封禁记录', 5, 3113, 0, NULL, 'nginx', NULL, '/logBan/logBanList', '2019-10-17 15:18:05', '2019-10-17 15:18:08');

--nginx_node 新增日志分析开启状态、封禁时间、封禁规则    2019.10.18  leibo
alter table nginx_list add log_analysis int(2) COMMENT '日志分析开关 0:关闭 1：开启';
alter table nginx_list add ban_time int(2) COMMENT '封禁时间(默认两小时)';
alter table nginx_list add ban_role  int(2)  COMMENT '封禁规则';

-- 增加路径新增 长链接  2019.10.18 zhangzhe
ALTER TABLE `local_name`
ADD COLUMN `long_link`  varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT 0 COMMENT '长链接(0为关 1为开)' AFTER `nginx_id`;

-- 增加消息推送 用户已读状态表  2019.10.18 zhangzhe
CREATE TABLE `notice_read` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(10) NOT NULL COMMENT '用户id',
  `notice_id` bigint(20) unsigned NOT NULL COMMENT '通知消息id',
  `sure_read` char(1) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '0' COMMENT '是否已读(0未读，1已读)',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- 增加消息推送表  2019.10.18 zhangzhe
CREATE TABLE `notice_info` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `content` text CHARACTER SET utf8 COLLATE utf8_general_ci COMMENT '消息内容',
  `info_type` varchar(10) DEFAULT NULL COMMENT '消息类型',
  `insert_time` datetime DEFAULT NULL COMMENT '插入时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- 新增字段gzip开启状态 2019.10.25 leibo
alter table local_name add gzip_status  int(2)  COMMENT 'gzip开启状态 0.关闭 1.开启';
-- 增加安全字段  2019.10.26 weiqi
ALTER TABLE `nginx_list` ADD COLUMN `safe_value`  int(11) NULL DEFAULT 0 COMMENT '安全信息(使用位来判断功能是否开启）' AFTER `black_lists`;

-- 新增字段is_filebeat 日志采集状态 2019.10.26 zengwenchao
alter table product add is_filebeat  int(2)  COMMENT '日志采集开启状态(0未开启 1已开启)';
